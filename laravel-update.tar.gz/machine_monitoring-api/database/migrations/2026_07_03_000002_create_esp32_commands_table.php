<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('esp32_commands', function (Blueprint $table) {
            $table->id();
            $table->string('device_id')->index();
            $table->string('machine_id')->nullable();
            $table->string('command');
            $table->integer('duration_minutes')->default(0);
            $table->string('status')->default('pending');
            $table->string('firestore_doc_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('esp32_commands');
    }
};
