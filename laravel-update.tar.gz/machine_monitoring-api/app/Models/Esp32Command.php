<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Esp32Command extends Model
{
    use HasFactory;

    protected $fillable = [
        'device_id',
        'machine_id',
        'command',
        'duration_minutes',
        'status',
        'firestore_doc_id',
    ];
}
