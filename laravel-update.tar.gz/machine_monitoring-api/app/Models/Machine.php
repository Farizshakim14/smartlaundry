<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Machine extends Model
{
    protected $fillable = [
        'store_id',
        'name',
        'type',
        'status',
        'price'
    ];
}
