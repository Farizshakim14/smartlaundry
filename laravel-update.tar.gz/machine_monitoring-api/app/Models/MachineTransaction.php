<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MachineTransaction extends Model
{
    protected $fillable = [
        'machine_id',
        'user_id',
        'start_time',
        'end_time',
        'energy_kwh',
        'cost',
        'status'
    ];

    protected $casts = [
        'start_time' => 'datetime',
        'end_time' => 'datetime',
    ];

    public function machine()
    {
        return $this->belongsTo(Machine::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
