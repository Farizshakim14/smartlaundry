<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ManualTransaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'store_id',
        'title',
        'amount',
        'type', // 'income' or 'expense'
        'timestamp', // to preserve exact time chosen by user if needed
    ];

    protected $casts = [
        'amount' => 'integer',
        'timestamp' => 'datetime',
    ];
}
