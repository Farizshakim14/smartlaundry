<?php

namespace App\Http\Controllers;

use App\Models\ManualTransaction;
use Illuminate\Http\Request;

class ManualTransactionController extends Controller
{
    public function index(Request $request)
    {
        $query = ManualTransaction::query();

        if ($request->has('store_id')) {
            // Can be single store_id or comma-separated list of store_ids for multiple branches
            $storeIds = explode(',', $request->store_id);
            if (count($storeIds) > 1) {
                $query->whereIn('store_id', $storeIds);
            } else {
                $query->where('store_id', $request->store_id);
            }
        }

        $transactions = $query->orderBy('timestamp', 'desc')->get();
        return response()->json(['transactions' => $transactions]);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'store_id' => 'required|string',
            'title' => 'required|string',
            'amount' => 'required|integer',
            'type' => 'required|in:income,expense',
            'timestamp' => 'nullable|date',
        ]);

        if (empty($validatedData['timestamp'])) {
            $validatedData['timestamp'] = now();
        }

        $transaction = ManualTransaction::create($validatedData);
        return response()->json(['message' => 'Transaction created successfully', 'transaction' => $transaction], 201);
    }

    public function update(Request $request, $id)
    {
        $transaction = ManualTransaction::findOrFail($id);

        $validatedData = $request->validate([
            'title' => 'sometimes|string',
            'amount' => 'sometimes|integer',
            'type' => 'sometimes|in:income,expense',
            'timestamp' => 'sometimes|date',
        ]);

        $transaction->update($validatedData);
        return response()->json(['message' => 'Transaction updated successfully', 'transaction' => $transaction]);
    }

    public function destroy($id)
    {
        $transaction = ManualTransaction::findOrFail($id);
        $transaction->delete();
        return response()->json(['message' => 'Transaction deleted successfully']);
    }
}
