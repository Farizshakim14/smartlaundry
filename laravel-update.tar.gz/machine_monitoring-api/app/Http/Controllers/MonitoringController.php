<?php

namespace App\Http\Controllers;

use App\Models\Machine;
use App\Models\MachineTransaction;
use Illuminate\Http\Request;
use Kreait\Laravel\Firebase\Facades\Firebase;

class MonitoringController extends Controller
{
    public function updateStatus(Request $request, $id)
    {
        // 1. Validasi data dari ESP32
        $validated = $request->validate([
            'status' => 'required|string|in:idle,running,error',
            'time_remaining' => 'nullable|integer',
            'power_usage' => 'nullable|numeric'
        ]);

        // 2. Simpan & Validasi Logika Bisnis di MySQL
        $machine = Machine::findOrFail($id);
        
        // Jika mesin baru saja SELESAI (berubah dari running -> idle)
        if ($machine->status === 'running' && $validated['status'] === 'idle') {
            // Catat ke tabel riwayat (transaction)
            MachineTransaction::create([
                'machine_id' => $machine->id,
                'status' => 'completed',
                // 'amount' => $machine->price, // (Sesuaikan dengan kolom tabel Anda jika ada)
            ]);
        }
        
        $machine->update([
            'status' => $validated['status'],
        ]);

        // 3. Tembak/Sync Data ke Firebase Realtime Database
        $database = Firebase::database();
        $database->getReference('machines/Mesin' . $id)->update([
            'status' => $validated['status'],
            'time_remaining' => $validated['time_remaining'] ?? 0,
            'power_usage' => $validated['power_usage'] ?? 0,
            'updatedAt' => time() * 1000,
        ]);

        return response()->json([
            'message' => 'Berhasil! Data tersimpan di MySQL dan tersinkronisasi ke Firebase.',
            'machine' => $machine
        ]);
    }
}
