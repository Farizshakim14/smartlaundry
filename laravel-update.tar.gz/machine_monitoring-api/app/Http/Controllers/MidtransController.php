<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Kreait\Laravel\Firebase\Facades\Firebase;
use App\Models\Machine;
use App\Models\MachineTransaction;
use App\Models\Esp32Command;

class MidtransController extends Controller
{
    public function webhook(Request $request)
    {
        \Midtrans\Config::$isProduction = false;
        \Midtrans\Config::$serverKey = env('MIDTRANS_SERVER_KEY', 'Mid-server-J-qOtKtk4PFJqZrS2LZs-bHI');

        try {
            $notif = new \Midtrans\Notification();
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }

        $transactionStatus = $notif->transaction_status;
        $fraudStatus = $notif->fraud_status;
        $orderId = $notif->order_id;

        $firestore = app('firebase.firestore')->database();

        if ($transactionStatus == 'capture' || $transactionStatus == 'settlement') {
            if ($fraudStatus == 'accept' || !$fraudStatus) {
                if (str_starts_with($orderId, 'MAC-')) {
                    $this->handleMachinePayment($orderId, $notif, $firestore);
                } elseif (str_starts_with($orderId, 'SRV-')) {
                    $this->handleServicePayment($orderId, $notif, $firestore);
                } else {
                    $this->handleTokenTopUp($orderId, $notif, $firestore);
                }
            }
        } elseif (in_array($transactionStatus, ['cancel', 'deny', 'expire'])) {
            $firestore->collection('token_requests')->document($orderId)->update([
                ['path' => 'status', 'value' => 'Failed']
            ]);
        }

        return response()->json(['status' => 'ok']);
    }

    private function handleMachinePayment($orderId, $notif, $firestore)
    {
        $docRef = $firestore->collection('machine_requests')->document($orderId);
        $docSnap = $docRef->snapshot();

        if ($docSnap->exists()) {
            $data = $docSnap->data();
            if ($data['status'] === 'Pending') {
                $docRef->update([['path' => 'status', 'value' => 'Approved']]);

                // Deduct token batch
                if (isset($data['batch_id']) && $data['batch_id']) {
                    $batchRef = $firestore->collection('stores')->document($data['store_id'])
                        ->collection('token_batches')->document($data['batch_id']);
                    $batchSnap = $batchRef->snapshot();
                    if ($batchSnap->exists() && $batchSnap->data()['remaining_tokens'] > 0) {
                        // Kreait Firebase doesn't have FieldValue::increment directly like JS, we must read and update
                        $rem = $batchSnap->data()['remaining_tokens'];
                        $batchRef->update([['path' => 'remaining_tokens', 'value' => $rem - 1]]);
                    }
                }

                // Activate machine in MySQL
                $machineId = $data['machine_id']; // This might be MySQL ID
                $machine = Machine::find($machineId);
                if ($machine) {
                    $machine->update(['status' => 'Active']);

                    // Trigger ESP32 Queue
                    if ($machine->device_id && $machine->relay_channel) {
                        Esp32Command::create([
                            'device_id' => $machine->device_id,
                            'machine_id' => $machine->relay_channel,
                            'command' => 'START',
                            'duration_minutes' => $data['duration_minutes'] ?? 0
                        ]);
                    }

                    // Log Transaction in MySQL
                    MachineTransaction::create([
                        'machine_id' => $machine->id,
                        'user_id' => null, // guest
                        'start_time' => now(),
                        'duration_minutes' => $data['duration_minutes'] ?? 0,
                        'price' => $data['price'] ?? 0,
                        'status' => 'Completed'
                    ]);
                }

                // Update RTDB for dashboard
                $database = Firebase::database();
                $database->getReference('machines/Mesin' . $machineId)->update([
                    'status' => 'Active',
                    'timer_enabled' => $data['timer_enabled'] ?? false,
                    'duration_minutes' => $data['duration_minutes'] ?? 0,
                    'start_time' => time() * 1000,
                    'payment_method' => 'QRIS Midtrans'
                ]);

                // Log Activity to Firestore
                $firestore->collection('stores')->document($data['store_id'])
                    ->collection('activities')->add([
                        'action' => "Memulai mesin {$data['machine_name']} via QRIS Midtrans",
                        'timestamp' => new \Google\Cloud\Core\Timestamp(new \DateTime())
                    ]);
            }
        }
    }

    private function handleServicePayment($orderId, $notif, $firestore)
    {
        // Service Payment logic...
        $docRef = $firestore->collection('service_requests')->document($orderId);
        $docSnap = $docRef->snapshot();

        if ($docSnap->exists()) {
            $data = $docSnap->data();
            if ($data['status'] === 'Pending Payment') {
                $docRef->update([['path' => 'status', 'value' => 'Paid']]);

                $qty = $data['quantity'] ?? 1;
                $washQty = $data['wash_quantity'] ?? ($data['service_type'] == 'Wash' || $data['service_type'] == 'Combo' ? $qty : 0);
                $dryQty = $data['dry_quantity'] ?? ($data['service_type'] == 'Dry' || $data['service_type'] == 'Combo' ? $qty : 0);

                if (isset($data['batch_id']) && $data['batch_id']) {
                    $batchRef = $firestore->collection('stores')->document($data['store_id'])
                        ->collection('token_batches')->document($data['batch_id']);
                    $batchSnap = $batchRef->snapshot();
                    if ($batchSnap->exists() && $batchSnap->data()['remaining_tokens'] > 0) {
                        $rem = $batchSnap->data()['remaining_tokens'];
                        $deduct = $washQty + $dryQty;
                        $batchRef->update([['path' => 'remaining_tokens', 'value' => max(0, $rem - $deduct)]]);
                    }
                }

                for ($i = 0; $i < $washQty; $i++) {
                    $firestore->collection('queues')->add([
                        'store_id' => $data['store_id'],
                        'customer_name' => $data['customer_name'],
                        'service_type' => $data['service_type'],
                        'step' => 'Wash',
                        'status' => 'Pending',
                        'created_at' => new \Google\Cloud\Core\Timestamp(new \DateTime())
                    ]);
                }

                for ($i = 0; $i < $dryQty; $i++) {
                    $firestore->collection('queues')->add([
                        'store_id' => $data['store_id'],
                        'customer_name' => $data['customer_name'],
                        'service_type' => $data['service_type'],
                        'step' => 'Dry',
                        'status' => 'Pending',
                        'created_at' => new \Google\Cloud\Core\Timestamp(new \DateTime())
                    ]);
                }

                // Call assignMachines logic (simulated by artisan command or job if complex)
                // For now we assume assignMachines logic will be triggered by a cron or job.
            }
        }
    }

    private function handleTokenTopUp($orderId, $notif, $firestore)
    {
        $docRef = $firestore->collection('token_requests')->document($orderId);
        $docSnap = $docRef->snapshot();

        if ($docSnap->exists()) {
            $data = $docSnap->data();
            if ($data['status'] === 'Pending') {
                $docRef->update([['path' => 'status', 'value' => 'Approved']]);

                $firestore->collection('stores')->document($data['store_id'])->collection('token_batches')->add([
                    'package_name' => $data['package_name'] ?? 'Midtrans Package',
                    'original_tokens' => $data['tokens'],
                    'remaining_tokens' => $data['tokens'],
                    'purchased_at' => new \Google\Cloud\Core\Timestamp(new \DateTime())
                ]);
            }
        }
    }
}
