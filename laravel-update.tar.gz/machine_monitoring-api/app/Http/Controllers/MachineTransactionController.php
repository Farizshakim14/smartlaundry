<?php

namespace App\Http\Controllers;

use App\Models\MachineTransaction;
use App\Models\Machine;
use Illuminate\Http\Request;

class MachineTransactionController extends Controller
{
    public function index(Request $request)
    {
        $query = MachineTransaction::with(['machine', 'user']);
        
        if ($request->has('store_id')) {
            $storeIds = explode(',', $request->store_id);
            $query->whereHas('machine', function($q) use ($storeIds) {
                if (count($storeIds) > 1) {
                    $q->whereIn('store_id', $storeIds);
                } else {
                    $q->where('store_id', $storeIds[0]);
                }
            });
        }
        
        $transactions = $query->orderBy('created_at', 'desc')->get();
        return response()->json(['transactions' => $transactions]);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'machine_id' => 'required|exists:machines,id',
            'user_id' => 'nullable|exists:users,id',
            'start_time' => 'nullable|date',
            'end_time' => 'nullable|date',
            'energy_kwh' => 'nullable|numeric',
            'cost' => 'nullable|numeric',
            'status' => 'nullable|string'
        ]);

        $transaction = MachineTransaction::create($validatedData);

        // Update machine status to running if applicable
        if (($validatedData['status'] ?? '') === 'running') {
            Machine::where('id', $validatedData['machine_id'])->update(['status' => 'running']);
        }

        return response()->json(['message' => 'Transaction created', 'transaction' => $transaction], 201);
    }
}
