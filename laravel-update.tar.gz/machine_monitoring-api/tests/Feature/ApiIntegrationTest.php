<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Machine;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ApiIntegrationTest extends TestCase
{
    use RefreshDatabase;

    public function test_auth_and_machines_flow(): void
    {
        // 1. Register a user
        $response = $this->postJson('/api/register', [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'password' => 'password123',
            'role' => 'admin'
        ]);

        $response->assertStatus(201)
                 ->assertJsonStructure(['access_token', 'user']);

        $token = $response->json('access_token');

        // 2. Profile with token
        $profileResponse = $this->withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->getJson('/api/profile');

        $profileResponse->assertStatus(200)
                        ->assertJsonPath('user.email', 'test@example.com');

        // 3. Create a machine
        $machineResponse = $this->withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->postJson('/api/machines', [
            'name' => 'Washer A1',
            'type' => 'Washer',
            'price' => 5000
        ]);

        $machineResponse->assertStatus(201)
                        ->assertJsonPath('machine.name', 'Washer A1');

        $machineId = $machineResponse->json('machine.id');

        // 4. Create a transaction
        $transactionResponse = $this->withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->postJson('/api/transactions', [
            'machine_id' => $machineId,
            'user_id' => $profileResponse->json('user.id'),
            'status' => 'running'
        ]);

        $transactionResponse->assertStatus(201);

        // 5. Verify machine status updated
        $verifyMachine = $this->withHeaders([
            'Authorization' => 'Bearer ' . $token,
        ])->getJson("/api/machines/{$machineId}");

        $verifyMachine->assertStatus(200)
                      ->assertJsonPath('machine.status', 'running');
    }
}
