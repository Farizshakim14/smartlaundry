<?php

// Test script for API endpoints

$baseUrl = 'http://localhost/api'; // Or use appropriate laragon URL if served
// But wait, it's better to use Artisan call or Laravel's internal testing.
// A simple way to test locally without spinning up a server is to use HTTP client
// But since the server might not be running, I can use Artisan tinkers or just run php artisan serve in the background and test.
